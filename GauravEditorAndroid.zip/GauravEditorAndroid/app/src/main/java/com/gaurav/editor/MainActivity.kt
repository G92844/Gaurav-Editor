package com.gaurav.editor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Ink = Color(0xFF11111B)
private val Panel = Color(0xFF202033)
private val Violet = Color(0xFF8065F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GauravEditorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GauravEditorApp() {
    var selectedTab by remember { mutableStateOf("Home") }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Choose a video or photo to begin") }
    var selectedTool by remember { mutableStateOf("Trim") }

    val pickMedia = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            status = "Media selected successfully"
        }
    }
    val capturePhoto = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) status = "Camera photo captured (preview). Save/import pipeline is next build step"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Video", "Photo").forEach { item ->
                    NavigationBarItem(
                        selected = selectedTab == item,
                        onClick = { selectedTab = item },
                        icon = { Icon(
                            when (item) {
                                "Video" -> Icons.Default.Movie
                                "Photo" -> Icons.Default.Image
                                else -> Icons.Default.Home
                            }, contentDescription = item
                        ) },
                        label = { Text(item) }
                    )
                }
            }
        }) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Violet, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GAURAV EDITOR", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("CREATE • EDIT • SHARE", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                    }
                    Surface(color = Violet.copy(alpha = .18f), shape = RoundedCornerShape(50)) {
                        Text("FREE + PRO", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color(0xFFC8B9FF), style = MaterialTheme.typography.labelSmall)
                    }
                }

                when (selectedTab) {
                    "Home" -> {
                        Text("What do you want to create?", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ActionCard("New Video", Icons.Default.VideoLibrary, Modifier.weight(1f)) {
                                selectedTab = "Video"
                                pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                            }
                            ActionCard("Edit Photo", Icons.Default.AddPhotoAlternate, Modifier.weight(1f)) {
                                selectedTab = "Photo"
                                pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        }
                        Text("Import media", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Collections, null); Spacer(Modifier.width(6.dp)); Text("Gallery")
                            }
                            OutlinedButton(onClick = { capturePhoto.launch(null) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(6.dp)); Text("Camera")
                            }
                        }
                        InfoPanel(status)
                        InfoPanel("Planned: AI tools • Multi-language UI • 4K export • No watermark")
                    }
                    "Video" -> {
                        Text("Video Studio", style = MaterialTheme.typography.titleLarge)
                        PreviewPanel(selectedUri, "VIDEO PREVIEW")
                        Text("Editing tools", style = MaterialTheme.typography.titleMedium)
                        ToolGrid(listOf("Trim", "Cut", "Merge", "Speed", "Music", "Voice", "Effects", "Text", "Crop"), selectedTool) { selectedTool = it }
                        InfoPanel("Selected: $selectedTool — editing engine integration is the next milestone.")
                        Button(onClick = { pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Import Video")
                        }
                    }
                    else -> {
                        Text("Photo Studio", style = MaterialTheme.typography.titleLarge)
                        PreviewPanel(selectedUri, "PHOTO PREVIEW")
                        Text("Photo tools", style = MaterialTheme.typography.titleMedium)
                        ToolGrid(listOf("Crop", "Filters", "Retouch", "Background", "Text", "Collage"), selectedTool) { selectedTool = it }
                        InfoPanel("Selected: $selectedTool — photo processing is planned for the next milestone.")
                        Button(onClick = { pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text("Import Photo")
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("GAURAV EDITOR • ANDROID ALPHA 1.0", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier.height(112.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(8.dp)); Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PreviewPanel(uri: Uri?, label: String) {
    Box(Modifier.fillMaxWidth().height(170.dp).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(if (uri == null) Icons.Default.PermMedia else Icons.Default.CheckCircle, null, tint = Violet, modifier = Modifier.size(38.dp))
            Spacer(Modifier.height(8.dp))
            Text(if (uri == null) label else "MEDIA SELECTED", fontWeight = FontWeight.Bold)
            if (uri != null) Text(uri.lastPathSegment ?: "Selected file", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ToolGrid(tools: List<String>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(tools) { tool ->
            FilterChip(selected = selected == tool, onClick = { onSelect(tool) }, label = { Text(tool) })
        }
    }
}

@Composable
private fun InfoPanel(message: String) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Text(message, modifier = Modifier.padding(14.dp), color = Color(0xFFD8D5E8), style = MaterialTheme.typography.bodyMedium)
    }
}
