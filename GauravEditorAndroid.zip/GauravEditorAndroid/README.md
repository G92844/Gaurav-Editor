# Gaurav Editor — Android starter project

A Kotlin + Jetpack Compose Android Studio starter for the Gaurav Editor app.

## Confirmed product choices
- Android app
- Gallery + Camera import entry points
- 4K export target (device/codec dependent)
- No watermark
- AI editing planned
- All-language UI planned
- Free + Premium model planned

## Open in Android Studio
1. Install Android Studio with JDK 17 and Android SDK Platform 35.
2. Open this folder (`GauravEditorAndroid`) in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Connect an Android device with USB debugging enabled, or create an emulator.
5. Select the `app` run configuration and press Run.

## Build a debug APK
From the project folder, run:

```bash
gradle assembleDebug
```

Or use Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Current prototype scope
- Compose-based dark professional home screen.
- Video, photo and home navigation.
- Android Photo Picker for selecting photos/videos from Gallery.
- Camera preview capture entry point.
- UI tool selection for common editing actions.
- Media3 Transformer dependencies included as the foundation for a real video export pipeline.

## Not implemented yet (important)
This is a starter UI project, not a finished editor. Actual trim/cut/merge/effects/audio mixing, full-resolution camera capture and saving, photo pixel processing, AI model/API integration, localization files, subscription billing, 4K export validation, and production QA still need implementation. 4K export depends on the phone's hardware codecs and available memory/storage. AI features may require a network service and could incur costs; do not add API keys to the app source.

## Suggested next milestones
1. Implement video timeline and Media3 Transformer export (1080p first, then device-tested 4K).
2. Implement photo crop/filter/retouch pipeline and save/share.
3. Add CameraX full-resolution capture and app media library.
4. Add sound library, voice-over and audio mixing.
5. Add AI features via a secure backend, with user consent and privacy controls.
6. Add localization, Play Billing, crash reporting, accessibility and device testing.

## Build an APK using only an Android phone (GitHub Actions)

This project includes `.github/workflows/android-apk.yml` for a cloud build.

1. On your phone, open GitHub in Chrome and sign in (create a free account if needed).
2. Create a **public or private repository** named `GauravEditor`.
3. Upload the extracted contents of this project (the files inside `GauravEditorAndroid`, not the outer folder) to the repository. Make sure `.github/workflows/android-apk.yml` is included. If GitHub's mobile upload flow hides dot-folders, use GitHub's web editor to create the workflow file at that exact path.
4. Open the repository's **Actions** tab, choose **Build Gaurav Editor APK**, then tap **Run workflow**.
5. When the run finishes successfully, open that run and download the artifact named **Gaurav-Editor-debug-APK**.
6. Extract the downloaded artifact and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/files app.

This produces a **debug/test APK**, not a Play Store release. The project still needs device testing and further implementation of real media editing, AI services, and 4K export before it is a complete editor. The debug APK is not a signed production release.
